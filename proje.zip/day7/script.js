let arr=[
    {
        "slno": 1,
        "name": "BANGALORE UNIVERSITY,JNANA BHARATHI CAMPUS",
        "address": "BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            60,
            3,
            0,
            4,
            53,
            57
        ]
    },
    {
        "slno": 2,
        "name": "MAHARANI'S CLUSTER UNIVERSITY",
        "address": "BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57
        ]
    },
    {
        "slno": 3,
        "name": "ACHARYA INSTITUTE OF GRADUATE STUDIES ",
        "address": "DR. SARVEPALLI RADHAKRISHNAN ROAD, SOLADEVANAHALLI HESARAGATTA MAIN ROAD,  BANGALORE - 560107",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 4,
        "name": "ACHARYA INSTITUTE OF MANAGEMENT AND SCIENCES",
        "address": "PEENYA,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 5,
        "name": "ACHARYA INSTITUTE OF TECHNOLOGY ",
        "address": "SOLDEVANAHALLI, HESARAGHATTA MAIN ROAD,BANGALORE -560090",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 6,
        "name": "ADITYA COLLEGE OF ENGINEERING AND TECHNOLOGY",
        "address": "SURVEY NO. 2/8,2/9 AND2/2, KAMAKSHIPURA, SONNENAHALLI PANCHAYATH, HESARAGHATTA HOBLI,  YELAHANKA, BENGALURU NORTH",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 7,
        "name": "ADMINISTRATIVE MANAGEMENT COLLEGE",
        "address": "18KM, BANNERGHATTA ROAD, KALKERE, BANGALORE - 560 083",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 8,
        "name": "AKASH GLOBAL COLLEGE OF MANAGEMENT AND SCIENCE",
        "address": "#43(P-1), DODDAJALA, BANGALORE NORTH, BANGALORE - 562157",
        "ins": "Ins",
        "total": "Total",
        "n": 300,
        "m": [
            150,
            8,
            1,
            11,
            130,
            141,
            150
        ]
    },
    {
        "slno": 9,
        "name": "AKASH INSTITUTE OF ENGINEERING AND TECHNOLOGY",
        "address": "NEAR INTERNATIONAL AIRPORT, PRASANNAHALLI MIAN ROAD, DEVANAHALLI, BANGALORE - 562110",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            2,
            0,
            2,
            26,
            28,
            30
        ]
    },
    {
        "slno": 10,
        "name": "AMC ENGINEERING COLLEGE",
        "address": "18KM, BANNERAGHATTA ROAD, KALKERE, BANGALORE -560083",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 11,
        "name": "ATRIA INSTITUTE OF TECHNOLOGY",
        "address": "ASKB CAMPUS, AG'S COLONY, 1ST MAIN, ANANDNAGAR, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 12,
        "name": "BANGALORE INSTITUTE OF TECHNOLOGY ",
        "address": "K.R.ROAD, V.V.PURAM, BANGALORE-560004",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            4,
            0,
            7,
            79,
            86,
            90
        ]
    },
    {
        "slno": 13,
        "name": "BMS COLLEGE OF ENGINEERING ",
        "address": "POST BOX NO 1908, BULL TEMPLE ROAD,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            4,
            53,
            57,
            60
        ]
    },
    {
        "slno": 14,
        "name": "BMS INSTITUTE OF TECHNOLOGY & MANAGEMENT",
        "address": "POST BOX NO.6443, AVALAHALLI,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            4,
            53,
            57,
            60
        ]
    },
    {
        "slno": 15,
        "name": "BRINDAVAN COLLEGE OF ENGINEERING",
        "address": "YELAHANKA, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 90,
        "m": [
            45,
            2,
            0,
            3,
            40,
            43,
            45
        ]
    },
    {
        "slno": 16,
        "name": "CAMBRIDGE INSTITUTE OF TECHNOLOGY ",
        "address": "K R PURAM,,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 17,
        "name": "CHRIST ACADEMY INSTITUTE FOR ADVANCED STUDIES",
        "address": "CHRIST NAGAR, HULLAHALLI, BEGUR - KOPPA ROAD, SAKKALAWARA POST, BANGALORE -560083",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 18,
        "name": "CITY COLLEGE",
        "address": "27/2 33RD CROSS 2ND MAIN JAYANAGAR 7TH BLOCK,,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 19,
        "name": "CITY ENGINEERING COLLEGE",
        "address": "DODDAKALLASANDRA, KANAKAPURA ROAD, BANGALORE.",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 20,
        "name": "CMR INSTITUTE OF TECHNOLOGY ",
        "address": "132, AECS LAYOUT,BANGALORE.",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            4,
            53,
            57,
            60
        ]
    },
    {
        "slno": 21,
        "name": "COMMUNITY INSTITUTE OF MANAGEMENT STUDIES ",
        "address": "2/1,  9TH CROSS ROAD, 9TH MAIN ROAD, 2ND BLOCK JAYANAGAR,BANGALORE.",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            4,
            53,
            57,
            60
        ]
    },
    {
        "slno": 22,
        "name": "DAYANANDA SAGAR ACADEMY OF TECHNOLOGY AND MANAGEMENT",
        "address": "UDAYA PURA, KANAKAPURA ROAD, BANGALORE-560068",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 23,
        "name": "DAYANANDA SAGAR COLLEGE OF ARTS,SCIENCE & COMMERCE",
        "address": "SHAVIGE MALLESHWARA HILLS, KUMARASWAMY LAYOUT, BANGALORE-560078",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 24,
        "name": "DAYANANDA SAGAR COLLEGE OF ENGINEERING",
        "address": "SHAVIGE MALLESHWARA HILLS, KUMARASWAMY LAYOUT, BANGALORE-560078",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 25,
        "name": "DHANWANTARI ACADEMY FOR MANAGEMENT STUDIES ",
        "address": "M A J FOUNDATION,VINAYAKA NAGAR, NEAR CHIKKABANAVARA RAILWAY STATION,CHIKKASANDRA,CHIKKABANAVARA,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 26,
        "name": "DR H N NATIONAL COLLEGE OF ENGINEERING",
        "address": "36 B CROSS, 7TH BLOCK JAYA NAGAR, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 27,
        "name": "DR. AMBEDKAR INSTITUTE OF TECHNOLOGY",
        "address": "OUTER RING ROAD, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 28,
        "name": "EAST WEST COLLEGE OF MANAGEMENT (MCA) ",
        "address": "#63, OFF MAGADI ROAD, VISHWANEEDAM POST, BANGALORE-91",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 29,
        "name": "G.T. INSTITUTE OF MANAGEMENT STUDIES AND RESEACH",
        "address": "#10/15, MAGADI MAIN ROAD, SUNKADAKATTE, VISHWANEEDAM POST, SRIGANDADAKAVALU, BANGALORE - 560091",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 30,
        "name": "GLOBAL INSTITUTE OF MANAGEMENT SCIENCE ",
        "address": "IDEAL HOMES TOWNSHIP,R.R.NAGAR,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 31,
        "name": "GS COLLEGE OF MANAGEMENT",
        "address": "9TH A CROSS, YELAHANKA NEW TOWN, BENGALURU, KA, INDIA",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            2,
            0,
            2,
            26,
            28,
            30
        ]
    },
    {
        "slno": 32,
        "name": "HARSHA INSTITUTE OF MANAGEMENT STUDIES",
        "address": "129/47/1 TO 7,VARADANAYAKANAHALLI,VILLAGE,THYAMAGONDLU HOBLI, NELAMANGALA TALUK,BANGALORE RURAL DISTRICT",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 33,
        "name": "INTERNATIONAL SCHOOL OF MANAGEMENT EXCELLENCE",
        "address": "SURVEY NO 88 & 89, CHEMBENHALLI VILLAGE, SARJAPURA ROAD, SARJAPURA HOBLI, ANEKAL TALUK, BANGALORE URBAN",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 34,
        "name": "JSS ACADEMY OF TECHNICAL EDUCATION",
        "address": "JSSATE CAMPUS, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            2,
            0,
            2,
            26,
            28,
            30
        ]
    },
    {
        "slno": 35,
        "name": "JYOTI NIVAS COLLEGE FOR WOMENS(MCA)",
        "address": "HOSUR ROAD, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 45,
        "m": [
            22,
            1,
            0,
            2,
            19,
            21,
            23
        ]
    },
    {
        "slno": 36,
        "name": "K.S.INSTITUTE OF TECHNOLOGY",
        "address": "#14,RAGUVANAHALLI, KANAKAPURA MAIN ROAD,BANGALORE - 560 062.",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 37,
        "name": "KLE SOCIETY'S S NIJALINGAPPA COLLEGE",
        "address": "2ND BLOCK, RAJAJINAGAR BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 40,
        "m": [
            20,
            1,
            0,
            1,
            18,
            19,
            20
        ]
    },
    {
        "slno": 38,
        "name": "KRISTU JAYANTI COLLEGE OF MANAGEMENT AND TECHNOLOGY (MCA)",
        "address": "K. NARAYANAPURA, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 39,
        "name": "KRUPANIDHI COLLEGE OF MANAGEMENT",
        "address": "NO. 12/1, CARMELARAM ROAD AND POST, CHIKKABELANDUR,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 40,
        "name": "M. S. RAMAIAH INSTITUTE OF TECHNOLOGY-MCA ",
        "address": "VIDYA SOUDHA, MSRIT POST,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 41,
        "name": "MOUNT CARMEL COLLEGE FOR WOMENS",
        "address": "NO. 58, PALACE ROAD,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 45,
        "m": [
            23,
            1,
            0,
            2,
            20,
            22,
            22
        ]
    },
    {
        "slno": 42,
        "name": "MVM COLLEGE OF ARTS SCIENCE AND MANAGEMENT",
        "address": "1336/72/2, VIKAS LAYOUT, VENKATALA, MARUTHINAGAR, YELAHANKA, BENGALURU",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 43,
        "name": "NEW HORIZON COLLEGE OF ENGINEERING (M&T)",
        "address": "RING ROAD, NEAR MARATHALLI, BELLANDUR POST,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 44,
        "name": "NITTE MEENAKSHI INSTITUTE OF TECHNOLOGY ",
        "address": "GOLLAHALLI, GOVINDAPURA,P.B NO 6429, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 45,
        "name": "PRESIDENCY COLLEGE ",
        "address": "NO.33/2C, 33/2D, KEMPAPURA, HEBBAL,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 300,
        "m": [
            150,
            8,
            1,
            11,
            130,
            141,
            150
        ]
    },
    {
        "slno": 46,
        "name": "R.V. COLLEGE OF ENGINEERING ",
        "address": "R.V. VIDYANIKETAN POST, MYSORE ROAD,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 47,
        "name": "RAJARAJESWARI COLLEGE OF ENGINEERING ",
        "address": "#14, RAMOHOLLI CROSS, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 180,
        "m": [
            90,
            5,
            1,
            7,
            77,
            84,
            90
        ]
    },
    {
        "slno": 48,
        "name": "RJS FIRST GRADE COLLEGE",
        "address": "NO.1, MAHAYOGI VEMANA ROAD, 16TH MAIN, KORAMANGALA 3RD BLOCK, BENGALURU",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 49,
        "name": "RNS INSTITUTE OF TECHNOLOGY ",
        "address": "CHANNASANDRA,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 50,
        "name": "RV INSTITUTE OF TECHNOLOGY AND MANAGEMENT ",
        "address": "KOTHANUR, 8TH PHASE J.P.NAGAR, BENGALURU-560 078.",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 51,
        "name": "SAMBHRAM ACADEMY OF MANAGEMENT STUDIES",
        "address": "JOTHI NAGAR, JALAHALLI EAST, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 52,
        "name": "SESHADRIPURAM COLLEGE",
        "address": "NO. 27, NAGAPPA STREET, SESHADRIPURAM, BENGALURU 560020",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 53,
        "name": "SESHADRIPURAM FIRST GRADE COLLEGE",
        "address": "CA SITE NUMBER 26, YELAHANKA -NEW TOWN, BENGALURU - 560 064.",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 54,
        "name": "SIR M. VISVESVARAYA INSTITUTE OF TECHNOLOGY",
        "address": "KRISHNADEVARAYA NAGAR, HUNASAMARANAHALLI,  BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            2,
            0,
            2,
            26,
            28,
            30
        ]
    },
    {
        "slno": 55,
        "name": "SRI VENKATESHWARA COLLEGE OF ENGINEERING",
        "address": "VIDYANAGAR, BENGALURU INTERNATIONAL AIRPORT ROAD,BETTAHALASUR POST, BENGALURU NORTH,BENGALURU - 562157",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            1,
            0,
            2,
            27,
            29,
            30
        ]
    },
    {
        "slno": 56,
        "name": "SURANA COLLEGE (AUTONOMOUS)",
        "address": "NO.17, 1ST MAIN, TUMKUR MYSORE RING ROAD, KENGERI SATELLITE TOWN,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 57,
        "name": "T JOHN COLLEGE",
        "address": "88/1,KAMMANAHALLI, GOTTIGERE POST,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 58,
        "name": "THE OXFORD COLLEGE OF ENGINEERING -( MCA)",
        "address": "HOSUR ROAD, BOMMANAHALLI,BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 120,
        "m": [
            60,
            3,
            0,
            5,
            52,
            57,
            60
        ]
    },
    {
        "slno": 59,
        "name": "THE OXFORD COLLEGE OF SCIENCE ",
        "address": "H.S.R LAYOUTI, BANGALORE",
        "ins": "Ins",
        "total": "Total",
        "n": 60,
        "m": [
            30,
            2,
            0,
            2,
            26,
            28,
            30
        ]
    }
];
let container = document.getElementsByClassName("container")[0];

function convertToGoogleMapsURL(address, n) {
    return (n == 1) ? address.replace(/\s+/g, '+') : address.replace(/\s+/g, '%20');
}

arr.forEach(element => {
    const formattedAddress = convertToGoogleMapsURL(element.address, 1);
    const forname = convertToGoogleMapsURL(element.name, 1);
    const mapadd = convertToGoogleMapsURL(element.address, 0);
    const mapnm = convertToGoogleMapsURL(element.name, 0);

    let dive = document.createElement("div");
    dive.className = "card";
    dive.innerHTML = `
        <div class="det">
            <h2>${element.slno}. ${element.name}</h2>
            <p><a href="https://www.google.com/maps/search/${forname}+${formattedAddress}">${element.address}</a></p>
        </div>  
        <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d3888.385062761012!2d77.50664365!3d12.947194300000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s${mapnm}%20${mapadd}!5e0!3m2!1sen!2sin!4v1728369355170!5m2!1sen!2sin" loading="lazy" allowfullscreen></iframe>
    `;
    container.appendChild(dive);
});